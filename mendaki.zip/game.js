const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let player = { x: 180, y: 500, width: 40, height: 40, color: 'red' };
let obstacles = [];
let score = 0;
let gameInterval;
let gameRunning = false;

function drawPlayer() {
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.width, player.height);
}

function drawObstacles() {
    ctx.fillStyle = 'brown';
    obstacles.forEach(obs => {
        ctx.fillRect(obs.x, obs.y, obs.width, obs.height);
    });
}

function updateObstacles() {
    for (let i = 0; i < obstacles.length; i++) {
        obstacles[i].y -= 2;
        if (obstacles[i].y + obstacles[i].height < 0) {
            obstacles.splice(i, 1);
            score++;
            i--;
        }
    }
    if (Math.random() < 0.02) {
        let width = Math.random() * 100 + 50;
        let x = Math.random() * (canvas.width - width);
        obstacles.push({ x: x, y: canvas.height, width: width, height: 20 });
    }
}

function detectCollision() {
    for (let obs of obstacles) {
        if (
            player.x < obs.x + obs.width &&
            player.x + player.width > obs.x &&
            player.y < obs.y + obs.height &&
            player.y + player.height > obs.y
        ) {
            return true;
        }
    }
    return false;
}

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawPlayer();
    drawObstacles();
    updateObstacles();
    if (detectCollision()) {
        clearInterval(gameInterval);
        gameRunning = false;
        alert('Game Over! Skormu: ' + score);
    }
    document.getElementById('score').innerText = 'Skor: ' + score;
}

document.getElementById('startBtn').addEventListener('click', () => {
    if (!gameRunning) {
        obstacles = [];
        player.x = 180;
        player.y = 500;
        score = 0;
        gameInterval = setInterval(gameLoop, 20);
        gameRunning = true;
    }
});

document.addEventListener('keydown', (e) => {
    const step = 20;
    if (e.key === 'ArrowLeft' && player.x > 0) player.x -= step;
    if (e.key === 'ArrowRight' && player.x + player.width < canvas.width) player.x += step;
});
